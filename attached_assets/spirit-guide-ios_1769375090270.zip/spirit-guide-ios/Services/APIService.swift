// ============================================
// SOULGUIDE - API SERVICE LAYER
// Connects to your Express backend
// ============================================

import Foundation

// MARK: - API Configuration

struct APIConfig {
    #if DEBUG
    static let baseURL = "http://localhost:5000/api"
    #else
    static let baseURL = "https://your-production-url.com/api"
    #endif
}

// MARK: - API Error

enum APIError: Error, LocalizedError {
    case invalidURL
    case noData
    case decodingError(Error)
    case serverError(Int, String)
    case networkError(Error)
    case unauthorized
    
    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "Invalid URL"
        case .noData:
            return "No data received"
        case .decodingError(let error):
            return "Failed to decode: \(error.localizedDescription)"
        case .serverError(let code, let message):
            return "Server error (\(code)): \(message)"
        case .networkError(let error):
            return "Network error: \(error.localizedDescription)"
        case .unauthorized:
            return "Please log in again"
        }
    }
}

// MARK: - API Client

actor APIClient {
    static let shared = APIClient()
    
    private let session: URLSession
    private var authToken: String?
    
    private init() {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 30
        config.timeoutIntervalForResource = 60
        self.session = URLSession(configuration: config)
    }
    
    func setAuthToken(_ token: String?) {
        self.authToken = token
    }
    
    // MARK: - Generic Request
    
    func request<T: Decodable>(
        endpoint: String,
        method: HTTPMethod = .get,
        body: Encodable? = nil,
        headers: [String: String]? = nil
    ) async throws -> T {
        guard let url = URL(string: "\(APIConfig.baseURL)\(endpoint)") else {
            throw APIError.invalidURL
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = method.rawValue
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Add auth token if available
        if let token = authToken {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        // Add custom headers
        headers?.forEach { request.setValue($1, forHTTPHeaderField: $0) }
        
        // Add body
        if let body = body {
            request.httpBody = try JSONEncoder().encode(body)
        }
        
        let (data, response) = try await session.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse else {
            throw APIError.noData
        }
        
        switch httpResponse.statusCode {
        case 200...299:
            do {
                let decoder = JSONDecoder()
                decoder.keyDecodingStrategy = .convertFromSnakeCase
                decoder.dateDecodingStrategy = .iso8601
                return try decoder.decode(T.self, from: data)
            } catch {
                throw APIError.decodingError(error)
            }
        case 401:
            throw APIError.unauthorized
        default:
            let message = String(data: data, encoding: .utf8) ?? "Unknown error"
            throw APIError.serverError(httpResponse.statusCode, message)
        }
    }
    
    // MARK: - Streaming Request (for AI chat)
    
    func streamRequest(
        endpoint: String,
        body: Encodable
    ) -> AsyncThrowingStream<String, Error> {
        AsyncThrowingStream { continuation in
            Task {
                guard let url = URL(string: "\(APIConfig.baseURL)\(endpoint)") else {
                    continuation.finish(throwing: APIError.invalidURL)
                    return
                }
                
                var request = URLRequest(url: url)
                request.httpMethod = "POST"
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                request.setValue("text/event-stream", forHTTPHeaderField: "Accept")
                
                if let token = authToken {
                    request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
                }
                
                request.httpBody = try? JSONEncoder().encode(body)
                
                do {
                    let (bytes, response) = try await session.bytes(for: request)
                    
                    guard let httpResponse = response as? HTTPURLResponse,
                          httpResponse.statusCode == 200 else {
                        continuation.finish(throwing: APIError.serverError(
                            (response as? HTTPURLResponse)?.statusCode ?? 0,
                            "Stream failed"
                        ))
                        return
                    }
                    
                    for try await line in bytes.lines {
                        if line.hasPrefix("data: ") {
                            let data = String(line.dropFirst(6))
                            if data != "[DONE]" {
                                continuation.yield(data)
                            }
                        }
                    }
                    
                    continuation.finish()
                } catch {
                    continuation.finish(throwing: APIError.networkError(error))
                }
            }
        }
    }
}

enum HTTPMethod: String {
    case get = "GET"
    case post = "POST"
    case put = "PUT"
    case patch = "PATCH"
    case delete = "DELETE"
}

// MARK: - API Response Models

struct APIResponse<T: Decodable>: Decodable {
    let success: Bool
    let data: T?
    let error: String?
}

// MARK: - Auth Models

struct LoginRequest: Encodable {
    let email: String
    let password: String
}

struct SignupRequest: Encodable {
    let name: String
    let email: String
    let password: String
}

struct AuthResponse: Decodable {
    let success: Bool
    let user: User?
    let token: String?
    let error: String?
}

struct User: Decodable, Identifiable {
    let id: Int
    let name: String
    let email: String
    let hasCompletedOnboarding: Bool
}

// MARK: - Persona Models

struct PersonaResponse: Decodable {
    let success: Bool
    let persona: UserPersona?
}

struct UserPersona: Decodable, Identifiable {
    let id: Int
    let userId: Int?
    let primaryStruggle: String?
    let primaryPersona: String?
    let graceArchetype: String?
    let graceMode: String?
    let graceTrust: TrustProfile?
}

struct TrustProfile: Decodable {
    let level: String
    let score: Int
}

struct OnboardingRequest: Encodable {
    let primaryStruggle: String?
    let depthLayer: [String: String]?
    let behavioralReality: BehavioralReality?
    let transformationGoals: [String]?
}

struct BehavioralReality: Encodable {
    let dailyRhythm: [String]?
    let pastConnectionMoment: String?
    let connectionRecency: String?
    let peakEnergyTime: String?
    let obstacles: [String]?
}

// MARK: - Conversation Models

struct Conversation: Decodable, Identifiable {
    let id: Int
    let title: String?
    let createdAt: Date
}

struct Message: Decodable, Identifiable {
    let id: Int
    let conversationId: Int
    let role: String
    let content: String
    let createdAt: Date
}

struct SendMessageRequest: Encodable {
    let content: String
}

struct ConversationResponse: Decodable {
    let success: Bool
    let conversation: Conversation?
    let messages: [Message]?
}

// MARK: - Prayer Models

struct PrayerRequest: Encodable {
    let content: String
    let isAnonymous: Bool
    let visibility: String
}

struct PrayerRequestResponse: Decodable {
    let id: Int
    let userId: Int
    let content: String
    let aiGeneratedPrayer: String?
    let prayerCount: Int
    let heartCount: Int
    let createdAt: Date
}

struct PrayerFeedResponse: Decodable {
    let success: Bool
    let prayers: [PrayerRequestResponse]
    let activePrayerCount: Int
}

struct PrayerInteractionRequest: Encodable {
    let prayerRequestId: Int
    let interactionType: String
    let prayerDurationSeconds: Int?
    let usedAiPrayer: Bool?
}

// MARK: - Devotional Models

struct Devotional: Decodable, Identifiable {
    let id: Int
    let title: String
    let subtitle: String?
    let scriptureReference: String
    let scriptureText: String
    let openingHook: String
    let reflectionContent: String
    let todaysPractice: String
    let closingPrayer: String
    let themes: [String]?
    let estimatedReadTime: Int
}

struct DevotionalResponse: Decodable {
    let success: Bool
    let devotional: Devotional?
    let streak: StreakInfo?
}

struct StreakInfo: Decodable {
    let currentStreak: Int
    let longestStreak: Int
    let totalCompleted: Int
}

// MARK: - Bible Models

struct BibleSearchRequest: Encodable {
    let query: String
    let translation: String
}

struct BibleSearchResponse: Decodable {
    let success: Bool
    let verses: [BibleVerseResult]
}

struct BibleVerseResult: Decodable, Identifiable {
    let id: String
    let reference: String
    let text: String
    let book: String
    let chapter: Int
    let verse: Int
    let translation: String
}

// MARK: - Auth Service

class AuthService: ObservableObject {
    static let shared = AuthService()
    
    @Published var currentUser: User?
    @Published var isAuthenticated: Bool = false
    @Published var isLoading: Bool = false
    
    private let api = APIClient.shared
    private let keychain = KeychainHelper.shared
    
    private init() {
        Task {
            await loadStoredAuth()
        }
    }
    
    func loadStoredAuth() async {
        if let token = keychain.get("authToken") {
            await api.setAuthToken(token)
            do {
                let response: AuthResponse = try await api.request(endpoint: "/auth/me")
                await MainActor.run {
                    self.currentUser = response.user
                    self.isAuthenticated = response.user != nil
                }
            } catch {
                await MainActor.run {
                    self.isAuthenticated = false
                }
            }
        }
    }
    
    func login(email: String, password: String) async throws {
        await MainActor.run { isLoading = true }
        defer { Task { @MainActor in isLoading = false } }
        
        let request = LoginRequest(email: email, password: password)
        let response: AuthResponse = try await api.request(
            endpoint: "/auth/login",
            method: .post,
            body: request
        )
        
        if let user = response.user, let token = response.token {
            keychain.set(token, forKey: "authToken")
            await api.setAuthToken(token)
            await MainActor.run {
                self.currentUser = user
                self.isAuthenticated = true
            }
        } else {
            throw APIError.serverError(401, response.error ?? "Login failed")
        }
    }
    
    func signup(name: String, email: String, password: String) async throws {
        await MainActor.run { isLoading = true }
        defer { Task { @MainActor in isLoading = false } }
        
        let request = SignupRequest(name: name, email: email, password: password)
        let response: AuthResponse = try await api.request(
            endpoint: "/auth/signup",
            method: .post,
            body: request
        )
        
        if let user = response.user, let token = response.token {
            keychain.set(token, forKey: "authToken")
            await api.setAuthToken(token)
            await MainActor.run {
                self.currentUser = user
                self.isAuthenticated = true
            }
        } else {
            throw APIError.serverError(400, response.error ?? "Signup failed")
        }
    }
    
    func logout() async {
        keychain.delete("authToken")
        await api.setAuthToken(nil)
        await MainActor.run {
            self.currentUser = nil
            self.isAuthenticated = false
        }
    }
}

// MARK: - Keychain Helper

class KeychainHelper {
    static let shared = KeychainHelper()
    
    func set(_ value: String, forKey key: String) {
        guard let data = value.data(using: .utf8) else { return }
        
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: key,
            kSecValueData as String: data
        ]
        
        SecItemDelete(query as CFDictionary)
        SecItemAdd(query as CFDictionary, nil)
    }
    
    func get(_ key: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: key,
            kSecReturnData as String: true
        ]
        
        var result: AnyObject?
        SecItemCopyMatching(query as CFDictionary, &result)
        
        guard let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
    
    func delete(_ key: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: key
        ]
        SecItemDelete(query as CFDictionary)
    }
}

// MARK: - Chat Service

class ChatService {
    static let shared = ChatService()
    
    private let api = APIClient.shared
    
    func getConversations() async throws -> [Conversation] {
        let response: APIResponse<[Conversation]> = try await api.request(endpoint: "/conversations")
        return response.data ?? []
    }
    
    func createConversation(title: String = "New Conversation") async throws -> Conversation {
        struct CreateRequest: Encodable {
            let title: String
        }
        let response: ConversationResponse = try await api.request(
            endpoint: "/conversations",
            method: .post,
            body: CreateRequest(title: title)
        )
        guard let conversation = response.conversation else {
            throw APIError.noData
        }
        return conversation
    }
    
    func getMessages(conversationId: Int) async throws -> [Message] {
        let response: ConversationResponse = try await api.request(
            endpoint: "/conversations/\(conversationId)/messages"
        )
        return response.messages ?? []
    }
    
    func sendMessage(conversationId: Int, content: String) -> AsyncThrowingStream<String, Error> {
        let request = SendMessageRequest(content: content)
        return api.streamRequest(
            endpoint: "/conversations/\(conversationId)/message",
            body: request
        )
    }
}

// MARK: - Prayer Service

class PrayerService {
    static let shared = PrayerService()
    
    private let api = APIClient.shared
    
    func getPrayerFeed(type: String = "live") async throws -> PrayerFeedResponse {
        try await api.request(endpoint: "/prayer/feed?type=\(type)")
    }
    
    func createPrayerRequest(content: String, isAnonymous: Bool = false) async throws -> PrayerRequestResponse {
        let request = PrayerRequest(content: content, isAnonymous: isAnonymous, visibility: "global")
        return try await api.request(endpoint: "/prayer/requests", method: .post, body: request)
    }
    
    func recordInteraction(prayerRequestId: Int, type: String, duration: Int? = nil) async throws {
        let request = PrayerInteractionRequest(
            prayerRequestId: prayerRequestId,
            interactionType: type,
            prayerDurationSeconds: duration,
            usedAiPrayer: type == "prayed"
        )
        let _: APIResponse<Bool> = try await api.request(
            endpoint: "/prayer/interactions",
            method: .post,
            body: request
        )
    }
}

// MARK: - Devotional Service

class DevotionalService {
    static let shared = DevotionalService()
    
    private let api = APIClient.shared
    
    func getTodayDevotional() async throws -> DevotionalResponse {
        try await api.request(endpoint: "/devotionals/today")
    }
    
    func markComplete(devotionalId: Int, timeSpent: Int) async throws {
        struct CompleteRequest: Encodable {
            let timeSpentSeconds: Int
        }
        let _: APIResponse<Bool> = try await api.request(
            endpoint: "/devotionals/\(devotionalId)/complete",
            method: .post,
            body: CompleteRequest(timeSpentSeconds: timeSpent)
        )
    }
    
    func getStreak() async throws -> StreakInfo {
        let response: APIResponse<StreakInfo> = try await api.request(endpoint: "/devotionals/streak")
        guard let streak = response.data else {
            throw APIError.noData
        }
        return streak
    }
}
