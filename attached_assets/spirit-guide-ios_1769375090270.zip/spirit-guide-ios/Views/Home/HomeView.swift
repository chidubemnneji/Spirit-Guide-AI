// ============================================
// SOULGUIDE - HOME SCREEN (TODAY'S JOURNEY)
// Matches Cross app "Today's Journey" design
// ============================================

import SwiftUI

// MARK: - Home View Model

@MainActor
class HomeViewModel: ObservableObject {
    @Published var userName: String = "Alex"
    @Published var currentStruggle: String = "Anxiety"
    @Published var streakCount: Int = 12
    @Published var todayProgress: Double = 0.25
    @Published var hasNotification: Bool = true
    
    @Published var tasks: [JourneyTask] = []
    @Published var expandedTaskId: UUID?
    
    @Published var isLoading: Bool = false
    @Published var showAIChat: Bool = false
    
    init() {
        loadTasks()
    }
    
    func loadTasks() {
        tasks = [
            JourneyTask(
                id: UUID(),
                duration: "1 MIN",
                title: "Soul Check-In",
                subtitle: "How close do you feel to God right now?",
                type: .soulCheckIn,
                progress: nil,
                aiPrompt: "Ask God for guidance"
            ),
            JourneyTask(
                id: UUID(),
                duration: "2 MIN",
                title: "God's Message",
                subtitle: "A word of peace for your heart",
                type: .godsMessage,
                progress: 0.17,
                previewText: "\"Do not be anxious about anything...\""
            ),
            JourneyTask(
                id: UUID(),
                duration: "1 MIN",
                title: "Daily Devotional",
                subtitle: "Personalized wisdom for your journey",
                type: .devotional,
                progress: 0.17
            ),
            JourneyTask(
                id: UUID(),
                duration: "1 MIN",
                title: "Today's Prayer",
                subtitle: "A moment of connection",
                type: .prayer,
                progress: nil
            )
        ]
    }
    
    func toggleTask(_ taskId: UUID) {
        withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
            if expandedTaskId == taskId {
                expandedTaskId = nil
            } else {
                expandedTaskId = taskId
            }
        }
    }
    
    func startAIGuidance(for task: JourneyTask) {
        showAIChat = true
        // Pass context to AI chat
    }
}

// MARK: - Journey Task Model

struct JourneyTask: Identifiable {
    let id: UUID
    let duration: String
    let title: String
    let subtitle: String
    let type: TaskType
    var progress: Double?
    var previewText: String?
    var aiPrompt: String?
    var isCompleted: Bool = false
    
    enum TaskType {
        case soulCheckIn
        case godsMessage
        case devotional
        case prayer
    }
}

// MARK: - Home View

struct HomeView: View {
    @StateObject private var viewModel = HomeViewModel()
    @State private var selectedTab: BottomNavigation.Tab = .home
    
    var body: some View {
        ZStack(alignment: .bottom) {
            // Background
            DesignTokens.Colors.background
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Header
                HomeHeader(
                    streakCount: viewModel.streakCount,
                    hasNotification: viewModel.hasNotification
                )
                
                // Scrollable Content
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: DesignTokens.Spacing.lg) {
                        // Title Section
                        TodayJourneyHeader(
                            struggle: viewModel.currentStruggle
                        )
                        
                        // Week Calendar
                        WeekCalendarView(selectedDate: Date())
                            .padding(.horizontal, DesignTokens.Spacing.md)
                        
                        // Progress Section
                        ProgressSection(progress: viewModel.todayProgress)
                            .padding(.horizontal, DesignTokens.Spacing.md)
                        
                        // Task Cards
                        VStack(spacing: DesignTokens.Spacing.sm) {
                            ForEach(viewModel.tasks) { task in
                                TaskCardView(
                                    task: task,
                                    isExpanded: viewModel.expandedTaskId == task.id,
                                    onTap: { viewModel.toggleTask(task.id) },
                                    onAIAction: { viewModel.startAIGuidance(for: task) }
                                )
                            }
                        }
                        .padding(.horizontal, DesignTokens.Spacing.md)
                        
                        // Bottom padding for nav bar
                        Spacer().frame(height: 100)
                    }
                }
                
                Spacer()
            }
            
            // Bottom Navigation
            BottomNavigation(selectedTab: $selectedTab)
        }
        .sheet(isPresented: $viewModel.showAIChat) {
            AIChatView()
        }
    }
}

// MARK: - Today's Journey Header

struct TodayJourneyHeader: View {
    let struggle: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: DesignTokens.Spacing.xs) {
            Text("Today's Journey")
                .font(DesignTokens.Typography.displayMedium)
                .foregroundColor(DesignTokens.Colors.textPrimary)
            
            HStack(spacing: DesignTokens.Spacing.xs) {
                Text("Seeking God's Help")
                    .font(DesignTokens.Typography.bodyMedium)
                    .foregroundColor(DesignTokens.Colors.textSecondary)
                
                Text("•")
                    .foregroundColor(DesignTokens.Colors.textTertiary)
                
                Text(struggle)
                    .font(DesignTokens.Typography.bodyMedium)
                    .foregroundColor(DesignTokens.Colors.textSecondary)
                
                Button(action: {}) {
                    Image(systemName: "info.circle")
                        .font(.system(size: 14))
                        .foregroundColor(DesignTokens.Colors.textTertiary)
                }
            }
        }
        .padding(.horizontal, DesignTokens.Spacing.md)
        .padding(.top, DesignTokens.Spacing.sm)
    }
}

// MARK: - Progress Section

struct ProgressSection: View {
    let progress: Double
    
    var body: some View {
        VStack(spacing: DesignTokens.Spacing.xs) {
            HStack {
                Text("PROGRESS TODAY")
                    .font(DesignTokens.Typography.labelSmall)
                    .foregroundColor(DesignTokens.Colors.textTertiary)
                    .tracking(1.2)
                
                Spacer()
                
                Text("\(Int(progress * 100))%")
                    .font(DesignTokens.Typography.labelMedium)
                    .foregroundColor(DesignTokens.Colors.textSecondary)
            }
            
            ProgressBar(progress: progress)
        }
    }
}

// MARK: - Task Card View

struct TaskCardView: View {
    let task: JourneyTask
    let isExpanded: Bool
    let onTap: () -> Void
    let onAIAction: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: DesignTokens.Spacing.sm) {
            // Header
            Button(action: onTap) {
                VStack(alignment: .leading, spacing: DesignTokens.Spacing.sm) {
                    // Duration badge
                    Text(task.duration)
                        .font(DesignTokens.Typography.labelSmall)
                        .foregroundColor(DesignTokens.Colors.textTertiary)
                        .padding(.horizontal, DesignTokens.Spacing.xs)
                        .padding(.vertical, DesignTokens.Spacing.xxxs)
                        .overlay(
                            RoundedRectangle(cornerRadius: DesignTokens.Radius.sm)
                                .stroke(Color(hex: "E0E0E0"), lineWidth: 1)
                        )
                    
                    HStack(alignment: .top) {
                        // Checkbox
                        Image(systemName: task.isCompleted ? "checkmark.square.fill" : "square")
                            .foregroundColor(task.isCompleted ? DesignTokens.Colors.primary : DesignTokens.Colors.textTertiary)
                            .font(.system(size: 22))
                        
                        VStack(alignment: .leading, spacing: 2) {
                            Text(task.title)
                                .font(DesignTokens.Typography.headlineMedium)
                                .foregroundColor(DesignTokens.Colors.textPrimary)
                            
                            Text(task.subtitle)
                                .font(DesignTokens.Typography.bodySmall)
                                .foregroundColor(DesignTokens.Colors.textSecondary)
                        }
                        
                        Spacer()
                        
                        Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                            .foregroundColor(DesignTokens.Colors.textTertiary)
                            .font(.system(size: 14, weight: .medium))
                    }
                }
            }
            .buttonStyle(PlainButtonStyle())
            
            // Expanded content
            if isExpanded {
                VStack(alignment: .leading, spacing: DesignTokens.Spacing.sm) {
                    // AI Action Button
                    if let aiPrompt = task.aiPrompt {
                        AIActionButton(
                            title: aiPrompt,
                            icon: "sparkles",
                            action: onAIAction
                        )
                    }
                    
                    // Preview text (for God's Message)
                    if let previewText = task.previewText {
                        Text(previewText)
                            .font(DesignTokens.Typography.bodyMedium)
                            .foregroundColor(DesignTokens.Colors.textSecondary)
                            .italic()
                            .padding(DesignTokens.Spacing.sm)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(DesignTokens.Colors.surfaceSecondary)
                            .cornerRadius(DesignTokens.Radius.sm)
                    }
                }
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
            
            // Progress bar (if applicable)
            if let progress = task.progress, progress > 0 && progress < 1.0 {
                HStack {
                    ProgressBar(progress: progress)
                    Text("\(Int(progress * 100))% Read")
                        .font(DesignTokens.Typography.caption)
                        .foregroundColor(DesignTokens.Colors.primary)
                }
            }
        }
        .padding(DesignTokens.Spacing.md)
        .background(DesignTokens.Colors.surface)
        .cornerRadius(DesignTokens.Radius.md)
        .shadow(color: Color.black.opacity(0.04), radius: 8, x: 0, y: 2)
        .animation(.spring(response: 0.3, dampingFraction: 0.7), value: isExpanded)
    }
}

// MARK: - Preview

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
